import os
import re

def replace_localized_strings(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    original_content = content

    # Substitui: "chave.localized" → "chave".localized
    pattern = r'"([a-zA-Z0-9_]+)\.localized"'
    replacement = r'"\1".localized'
    content = re.sub(pattern, replacement, content)

    # Opcional: remove "" (string vazia) com .localized → apenas ignora
    content = re.sub(r'""\.localized', '""', content)

    if content != original_content:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"✔️ Corrigido: {file_path}")

def walk_and_replace_localized():
    root_dir = os.path.dirname(os.path.abspath(__file__))  # Pasta atual do script
    for root, _, files in os.walk(root_dir):
        for file in files:
            if file.endswith(".swift"):
                replace_localized_strings(os.path.join(root, file))

if __name__ == "__main__":
    walk_and_replace_localized()
